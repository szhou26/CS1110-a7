"""
Models module for Planetoids

This module contains the model classes for the Planetoids game. Anything that you
interact with on the screen is model: the ship, the bullets, and the planetoids.

We need models for these objects because they contain information beyond the simple
shapes like GImage and GEllipse. In particular, ALL of these classes need a velocity
representing their movement direction and speed (and hence they all need an additional
attribute representing this fact). But for the most part, that is all they need. You
will only need more complex models if you are adding advanced features like scoring.

You are free to add even more models to this module. You may wish to do this when you
add new features to your game, such as power-ups. If you are unsure about whether to
make a new class or not, please ask on Ed Discussions.

Shelly Zhou sz498
12/06/2022
"""
from consts import *
from game2d import *
from introcs import *
import math

# PRIMARY RULE: Models are not allowed to access anything in any module other than
# consts.py. If you need extra information from Gameplay, then it should be a 
# parameter in your method, and Wave should pass it as a argument when it calls 
# the method.

# START REMOVE
# HELPER FUNCTION FOR MATH CONVERSION
def degToRad(deg):
    """
    Returns the radian value for the given number of degrees
    
    Parameter deg: The degrees to convert
    Precondition: deg is a float
    """
    return math.pi*deg/180
# END REMOVE


class Bullet(GEllipse):
    """
    A class representing a bullet from the ship
    
    Bullets are typically just white circles (ellipses). The size of the bullet is 
    determined by constants in consts.py. However, we MUST subclass GEllipse, because 
    we need to add an extra attribute for the velocity of the bullet.
    
    The class Wave will need to look at this velocity, so you will need getters for
    the velocity components. However, it is possible to write this assignment with no 
    setters for the velocities. That is because the velocity is fixed and cannot change 
    once the bolt is fired.
    
    In addition to the getters, you need to write the __init__ method to set the starting
    velocity. This __init__ method will need to call the __init__ from GEllipse as a
    helper. This init will need a parameter to set the direction of the velocity.
    
    You also want to create a method to update the bolt. You update the bolt by adding
    the velocity to the position. While it is okay to add a method to detect collisions
    in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    #ATTRIBUTE _velocity: the velocity of the bullet
    #INVARIANT: _velocity is a Vector2 object
    #ATTRIBUTE _remove: True if bullet travels out of bounds and should be removed, else False
    #INVARIANT _remove is a bool

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getVelocity(self):
        """
        Returns _velocity attribute
        """
        return self._velocity
    def getRemove(self):
        """
        returns the _remove attribute
        """
        self.remove()
        return self._remove

    # INITIALIZER TO SET THE POSITION AND VELOCITY
    def __init__(self, x, y, width, height, fillcolor, velocity):
        """
        Initiates a new Bullet object

        Parameter x: x position of the bullet
        Precondition: x is a number that represents the x coordinate in the view

        Parameter y: y position
        Precondition: y is a number that represents the y coordinate in the view

        Parameter width: width of the bullet
        Precondition: width is a number and is the ship radius*2

        Parameter height: height of the bullet
        Precondition: Height is a number and is the ship radius*2
        
        Parameter angle: angle of the bullet
        Precondition: angle is in degrees or radians

        Parameter fillcolor: the color of the bullet image
        Precondition: fillcolor is a valid bullet color
        """
        super().__init__(x=x, y=y, width=width, height= height, fillcolor= fillcolor)
        self._velocity = velocity
        self._remove = False

    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)
    
    def move(self):
        """
        Moves a Bullet object by determing its new position by adding
        the old position to its velocity
        """
        self.x = self.x + self._velocity.x
        self.y = self.y + self._velocity.y
    
    def remove(self):
        """
        Sets _remove to True if the bullet position crosses a dead zone.
        If _remove is True, it is marked to be deleted
        """
        if self.x < -DEAD_ZONE:
            self._remove = True
        if self.x > GAME_WIDTH+DEAD_ZONE:
            self._remove = True
        if self.y < -DEAD_ZONE:
            self._remove = True
        if self.y > GAME_HEIGHT+DEAD_ZONE:
            self._remove = True

class Ship(GImage):
    """
    A class to represent the game ship.
    
    This ship is represented by an image. The size of the ship is determined by constants 
    in consts.py. However, we MUST subclass GEllipse, because we need to add an extra 
    attribute for the velocity of the ship, as well as the facing vector (not the same)
    thing.
    
    The class Wave will need to access these two values, so you will need getters for 
    them. But per the instructions,these values are changed indirectly by applying thrust 
    or turning the ship. That means you won't want setters for these attributes, but you 
    will want methods to apply thrust or turn the ship.
    
    This class needs an __init__ method to set the position and initial facing angle.
    This information is provided by the wave JSON file. Ships should start with a shield
    enabled.
    
    Finally, you want a method to update the ship. When you update the ship, you apply
    the velocity to the position. While it is okay to add a method to detect collisions 
    in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY

    # ATTRIBUTE _velocity: the direction the speed the ship is traveling
    # INVARIANT: _velocity is a Vector2 Object
    # ATTRIBUTE _facing: the diretion the ship is facing
    # INVARIANT: _facing is a Vector2 Object that depends on the angle of the ship
    # ATTRIBUTE _angle: the angle of the ship measured counterclockwise from x-axis
    # INVARIANT: _angle is in degrees of radians

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getFacing(self):
        """
        returns the _facing attribute of the ship
        """
        return self._facing 
    
    def getVelocity(self):
        """
        returns the velocity of the ship
        """
        return self._velocity

    # INITIALIZER TO CREATE A NEW SHIP
    def __init__(self, x, y, width, height, angle, source):
        """
        Initializes a new ship as a GImage Object.

        Parameter x: x position of the ship
        Precondition: x is a number that represents a coordinate in the view

        Parameter y: y position of the ship
        Precondition: y is a number that represents a coordinate in the view

        Parameter width: width of the ship
        Precondition: width is the radius of the ship*2

        Parameter height: height of the ship
        Precondition: height is the radius of the ship*2

        Parameter angle: angle of the ship
        Precondition: angle is in degrees or radians

        Parameter source: the source image = SHIP_IMAGE
        Precondition: source is a valid image
        """
        super().__init__(x=x, y=y, width=width, height= height, angle = angle, source= SHIP_IMAGE)
        self._velocity = introcs.Vector2(0,0)
        self._angle = angle
        f = degToRad(self.angle)
        self._facing = introcs.Vector2(introcs.math.cos(f),introcs.math.sin(f))
    

    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)
    def turn(self,input):
        """
        Helper method that turns the ship when 'right' and 'left' are pressed
        1. updates angle by adding or subtracting the SHIP_TURN_RATE
        2. updates _facing using the updated angle value
        """
        if input.is_key_down('right') == True:
            self.angle = self.angle - SHIP_TURN_RATE
            f = degToRad(self.angle)
            self._facing = introcs.Vector2(introcs.math.cos(f),introcs.math.sin(f))
        if input.is_key_down('left') == True:
            self.angle = self.angle + SHIP_TURN_RATE
            f = degToRad(self.angle)
            self._facing = introcs.Vector2(introcs.math.cos(f),introcs.math.sin(f))
    
    def move(self, input):
        """
        Method that moves the ship by applying an impulse to the ship.
        Adds old velocity of the ship to the impusle to get new velocity.
        And adding old position of ship to the velocity to get new ship position

        If the ship crosses the dead zones, it is wrapped and appears on the 
        vertical or horizontal opposite sides
        """
        self.x = self.x + self._velocity.x
        self.y = self.y + self._velocity.y
        if input.is_key_down('up') == True:
            self._impulse = self.getFacing()*SHIP_IMPULSE
            self._velocity = self._impulse + self.getVelocity()
            if self._velocity.x or self._velocity.y > SHIP_MAX_SPEED:
                self._velocity.normalize()
                self._velocity = self.getVelocity()*SHIP_MAX_SPEED
            self.x = self.x + self._velocity.x
            self.y = self.y + self._velocity.y

        
        if self.x < -DEAD_ZONE:
            self.x = GAME_WIDTH+DEAD_ZONE
        if self.x > GAME_WIDTH+DEAD_ZONE:
            self.x = -DEAD_ZONE
        if self.y < -DEAD_ZONE:
            self.y = GAME_HEIGHT+DEAD_ZONE
        if self.y > GAME_HEIGHT+DEAD_ZONE:
            self.y = -DEAD_ZONE
        

class Asteroid(GImage):
    """
    A class to represent a single asteroid.
    
    Asteroids are typically are represented by images. Asteroids come in three 
    different sizes (SMALL_ASTEROID, MEDIUM_ASTEROID, and LARGE_ASTEROID) that 
    determine the choice of image and asteroid radius. We MUST subclass GImage, because 
    we need extra attributes for both the size and the velocity of the asteroid.
    
    The class Wave will need to look at the size and velocity, so you will need getters 
    for them.  However, it is possible to write this assignment with no setters for 
    either of these. That is because they are fixed and cannot change when the planetoid 
    is created. 
    
    In addition to the getters, you need to write the __init__ method to set the size
    and starting velocity. Note that the SPEED of an asteroid is defined in const.py,
    so the only thing that differs is the velocity direction.
    
    You also want to create a method to update the asteroid. You update the asteroid 
    by adding the velocity to the position. While it is okay to add a method to detect 
    collisions in this class, you may find it easier to process collisions in wave.py.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # ATTRIBUTE _size: the size of the asteroid
    # INVARIANT: must be 'LARGE_ASTEROID', 'MEDIUM_ASTEROID', or 'SMALL_ASTERIOD'
    # ATTRIBUTE _velocity: the velocity of the asteroid
    # INVARIANT: is a Vector2 object

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getSize(self):
        """
        retuns the size of the asteroid object
        """
        return self._size
    
    def getVelocity(self):
        """
        returns the velocity of the asteroid object
        """
        return self._velocity

    # INITIALIZER TO CREATE A NEW ASTEROID
    def __init__(self, x, y, width, height, source, _size, _velocity):
        """
        Initializes a new Asteroid Object with an Asteriod size and an Asteroid velocity, depending on its size

        Parameter x: x position of the asteroid
        Precondition: x is a number that represents a coordinate in the view

        Parameter y: y position of the asteroid
        Precondition: y is a number that represents a coordinate in the view

        Parameter width: width of the asteroid
        Precondition: width is the radius of the asteroid*2

        Parameter height: height of the asteroid
        Precondition: height is the radius of the asteroid*2

        Parameter angle: angle of the asteroid
        Precondition: angle is in degrees or radians

        Parameter source: the source image depending on the size of the asteroid
        Precondition: source is a valid asteroid image

        Parameter _size: the size of the asteroid
        Precondition: must be 'LARGE_ASTEROID', 'MEDIUM_ASTEROID', or 'SMALL_ASTERIOD'

        Parameter _velocity: the velocity of the asteroid
        Precondition velocity is a Vector2 Object 
        """
        super().__init__(x=x, y=y, width=width, height= height, source= source)
        self._size = _size
        self._velocity = _velocity
 

    # ADDITIONAL METHODS (MOVEMENT, COLLISIONS, ETC)
    def move(self):
        """
        This method moves the asteroids by adding the old position to the velocity 
        of the asteroid to get a new position.

        The asteroid is vertically and horizontally wrapped so it appears on the opposite
        sides when it crosses the dead zones.
        """
        self.x = self.x + self._velocity.x
        self.y = self.y + self._velocity.y
        if self.x < -DEAD_ZONE:
            self.x = GAME_WIDTH+DEAD_ZONE
        if self.x > GAME_WIDTH+DEAD_ZONE:
            self.x = -DEAD_ZONE
        if self.y < -DEAD_ZONE:
            self.y = GAME_HEIGHT+DEAD_ZONE
        if self.y > GAME_HEIGHT+DEAD_ZONE:
            self.y = -DEAD_ZONE

# IF YOU NEED ADDITIONAL MODEL CLASSES, THEY GO HERE