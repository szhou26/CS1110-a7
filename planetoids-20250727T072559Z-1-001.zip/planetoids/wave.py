"""
Subcontroller module for Planetoids

This module contains the subcontroller to manage a single level (or wave) in the 
Planetoids game.  Instances of Wave represent a single level, and should correspond
to a JSON file in the Data directory. Whenever you move to a new level, you are 
expected to make a new instance of the class.

The subcontroller Wave manages the ship, the asteroids, and any bullets on screen. These 
are model objects. Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or models.py.
Whether a helper method belongs in this module or models.py is often a complicated
issue.  If you do not know, ask on Ed Discussions and we will answer.

Shelly Zhou sz498
12/06/2022
"""
from game2d import *
from consts import *
from models import *
import random
import datetime

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Level is NOT allowed to access anything in app.py (Subcontrollers are not permitted
# to access anything in their parent. To see why, take CS 3152)

class Wave(object):
    """
    This class controls a single level or wave of Planetoids.
    
    This subcontroller has a reference to the ship, asteroids, and any bullets on screen.
    It animates all of these by adding the velocity to the position at each step. It
    checks for collisions between bullets and asteroids or asteroids and the ship 
    (asteroids can safely pass through each other). A bullet collision either breaks
    up or removes a asteroid. A ship collision kills the player. 
    
    The player wins once all asteroids are destroyed.  The player loses if they run out
    of lives. When the wave is complete, you should create a NEW instance of Wave 
    (in Planetoids) if you want to make a new wave of asteroids.
    
    If you want to pause the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lecture 25 for an example.  This class will be similar to
    than one in many ways.
    
    All attributes of this class are to be hidden. No attribute should be accessed 
    without going through a getter/setter first. However, just because you have an
    attribute does not mean that you have to have a getter for it. For example, the
    Planetoids app probably never needs to access the attribute for the bullets, so 
    there is no need for a getter there. But at a minimum, you need getters indicating
    whether you won or lost the game.
    """
    # LIST ANY ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    # THE ATTRIBUTES LISTED ARE SUGGESTIONS ONLY AND CAN BE CHANGED AS YOU SEE FIT
    # Attribute _data: The data from the wave JSON, for reloading 
    # Invariant: _data is a dict loaded from a JSON file
    #
    # Attribute _ship: The player ship to control 
    # Invariant: _ship is a Ship object
    #
    # Attribute _asteroids: the asteroids on screen 
    # Invariant: _asteroids is a list of Asteroid, possibly empty
    #
    # Attribute _bullets: the bullets currently on screen 
    # Invariant: _bullets is a list of Bullet, possibly empty
    #
    # Attribute _lives: the number of lives left 
    # Invariant: _lives is an int >= 0
    #
    # Attribute _firerate: the number of frames until the player can fire again 
    # Invariant: _firerate is an int >= 0

    # Attribute _counter: counts the number of frames since last fired a bullet
    # Invariant: _counter is an integer >= 0
    #
    # Attribute _collided: key word that determines if two objects have collided
    # Invariant: _collided is a bool
    #
    # Attribute _cvector: the collision vector after destroying larger asteroids 
    # Invariant: _cvector is a Vector2 object
    #
    # Attribute _result1: the resuting vector with a rotation of 120 degrees
    # Invariant: _result1 is a Vector2 object   
    #    
    # Attribute _result2: the resulting vector with a rotation of 240 degrees
    # Invariant: _result2 is a Vector2 object   
    #  
    # Attribute _result3 the resulting vector with a rotation of 360 degrees
    # Invariant: _result3 is a Vector2 object   


    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getLives(self):
        """
        returns the attribute _lives
        """
        return self._lives
    
    def getAsteroids(self):
        """
        returns the list of asteroids
        """
        return self._asteroids

    # INITIALIZER (standard form) TO CREATE SHIP AND ASTEROIDS
    def __init__(self, json):
        """
        Initializes a new Wave object, creates the ship and asteroids.

        Parameter json: a dictionary with data on ship and asteroids
        Precondition: json is a json file
        """
        self._data = json
        self._ship = Ship(self._data['ship']['position'][0], self._data['ship']['position'][1],\
        2*SHIP_RADIUS, 2*SHIP_RADIUS, self._data['ship']['angle'], SHIP_IMAGE)
        self._asteroids = []
        self.addasteroids()
        self._bullets = []
        self._counter = 0
        self._collided = False
        self._cvector = self._ship.getFacing()*BULLET_SPEED
        self._result1 = introcs.Vector2((self._cvector.x*(introcs.math.cos(math.pi*120/180)))\
        - (self._cvector.y*(introcs.math.sin(math.pi*120/180))), (self._cvector.x*(introcs.math.sin(math.pi*120/180)))\
        + (self._cvector.y*(introcs.math.cos(math.pi*120/180)))).normalize()
        self._result2 = introcs.Vector2((self._cvector.x*(introcs.math.cos(math.pi*240/180)))\
        - (self._cvector.y*(introcs.math.sin(math.pi*240/180))), (self._cvector.x*(introcs.math.sin(math.pi*240/180)))\
        + (self._cvector.y*(introcs.math.cos(math.pi*240/180)))).normalize()
        self._result3 = introcs.Vector2((self._cvector.x*(introcs.math.cos(math.pi*360/180)))\
        - (self._cvector.y*(introcs.math.sin(math.pi*360/180))), (self._cvector.x*(introcs.math.sin(math.pi*360/180)))\
        + (self._cvector.y*(introcs.math.cos(math.pi*360/180)))).normalize()
        self._lives = 3

    # UPDATE METHOD TO MOVE THE SHIP, ASTEROIDS, AND BULLETS
    def update(self,dt,input):
        """
        Animates a single frame in the game.

        This moves the ship, asteroids, and bullets.
        Detects collisions and removes objects from lists after collision
        """ 
        self.detectship()
        self.removeship()
        self.detectbullet()
        if self._ship != None:
            for d in self._asteroids:
                d.move()
            if input.is_key_down('spacebar') == True and self._counter >= BULLET_RATE:
                self.shoot()
                self._counter = 0
            else:
                self._counter = self._counter + 1
            for bullet in self._bullets:
                bullet.move()
            self.removebullet()
            #if input.is_key_down('up') == True:
            self._ship.move(input)
            if input.is_key_down('right') == True:
                self._ship.turn(input)
            if input.is_key_down('left') == True:
                self._ship.turn(input)

        
    # DRAW METHOD TO DRAW THE SHIP, ASTEROIDS, AND BULLETS
    def draw(self, view):
        """
        Draws the ship, the asteroids, and the bullets onto the view.
        """
        if self._ship != None:
            self._ship.draw(view)
        for d in self._asteroids:
            d.draw(view)
        for bullet in self._bullets:
            bullet.draw(view)

    # HELPER METHODS FOR PHYSICS AND COLLISION DETECTION
    def addasteroids(self):
        """
        Helper method to append asteroids to list of asteroids by
        looping over the json dictionary. 

        Creates an asteroid object after getting getting the position, direction, and size.
        """
        for a in range(len(self._data['asteroids'])):
            for b in range(len(self._data['asteroids'][a]['position'])):
                x = self._data['asteroids'][a]['position'][0]
                y = self._data['asteroids'][a]['position'][1]
            direction = introcs.Vector2(self._data['asteroids'][a]['direction'][0],\
            self._data['asteroids'][a]['direction'][1])
            if direction != [0,0]:
                direction.normalize()
            if self._data['asteroids'][a]['size'] == 'small':
                d = Asteroid(x,y,SMALL_RADIUS*2,SMALL_RADIUS*2,SMALL_IMAGE,\
                SMALL_ASTEROID,direction*SMALL_SPEED)
                self._asteroids.append(d)
            if self._data['asteroids'][a]['size'] == 'medium':
                d = Asteroid(x,y,MEDIUM_RADIUS*2,MEDIUM_RADIUS*2,MEDIUM_IMAGE,\
                MEDIUM_ASTEROID,direction*MEDIUM_SPEED)
                self._asteroids.append(d)
            if self._data['asteroids'][a]['size'] == 'large':
                d = Asteroid(x,y,LARGE_RADIUS*2,LARGE_RADIUS*2,LARGE_IMAGE,\
                LARGE_ASTEROID,direction*LARGE_SPEED)
                self._asteroids.append(d)
        
    
    def shoot(self):
        """
        Creates bullet objects to add to list of bullets, _bullets
        The bullet is placed on the tip of the ship.
        """
        pos = self._ship.getFacing()
        x = pos.x*SHIP_RADIUS+self._ship.x
        y = pos.y*SHIP_RADIUS+self._ship.y
        v = self._ship.getFacing()*BULLET_SPEED            
        bullet = Bullet(x,y, BULLET_RADIUS*2, BULLET_RADIUS*2, BULLET_COLOR, v)
        self._bullets.append(bullet)
    
    def removebullet(self):
        """
        Removes bullet from list of bullets if it is marked to be removed by
        the attribute _remove
        """        
        i = 0
        while i < len(self._bullets):
            if self._bullets[i].getRemove() == True: 
                del self._bullets[i]
            else:
                i += 1

    def detectship(self):
        """
        Detects if a collision occurs between ship and asteroid.

        A collision is detected if the distance between the center
        of two objects is less than the sum of the radii of the two circles.

        If they overlap, attribute _collided is True and calls a method to remove the ship.
        """
        for a in self._asteroids:
            if self._ship != None:
                distance = math.sqrt((self._ship.x-a.x)**2+(self._ship.y-a.y)**2)
                if distance < SHIP_RADIUS + a.width/2:
                    self._collided = True
                    self.removeship()
                else: 
                    self._collided = False

    def detectbullet(self):
        """
        Detects if a collision occurs between bullet and asteroid.

        A collision is detected if the distance between the center
        of two objects is less than the sum of the radii of the two circles.

        If they overlap, _collided is True and calls another method
        to break up the asteroid into smaller peices and deletes them 
        if the asteriod size is small.
        """
        for a in self._asteroids:
            for b in self._bullets:
                distance = math.sqrt((b.x-a.x)**2+(b.y-a.y)**2)
                if distance < BULLET_RADIUS + a.width/2:
                    self._collided = True
                    self.breakup(a,b)
                    self._collided = False
                else:
                    self._collided = False

    def removeship(self):
        """
        Removes the ship by setting it to None when a collision 
        occurs between the ship and asteroid.

        One life is loss and _lives is decreased by one when the ship collides 
        with an asteroid.
        """
        if self._collided == True:
            self._ship = None
            self._collided = False
            self._lives = self._lives - 1
            
    
    def breakup(self,a,b):
        """
        This method breaks up asteroids when it is hit by a bullet object.
        If the size of the asteroid that collided with the bullet is large, it calls
        a method to break the asteroid into 3 medium asteroids and deletes the large asteroid 
        from the list.

        If the asteroid that collided with the bullet is medium sized, it calls a method
        that breaks the asteroid into 3 small asteroids and deletes the medium asteroid from the list.

        If the asteriod that collided with the bullet is small, the asteroid is destroyed 
        and is removed from the asteroid list.
        """
        if self._collided == True:
            if a.getSize() == LARGE_ASTEROID:
                self._asteroids.remove(a)
                self._bullets.remove(b)
                self.mediums(a,b)
            elif a.getSize() == MEDIUM_ASTEROID:
                self._asteroids.remove(a)
                self._bullets.remove(b)
                self.smalls(a,b)
            else:
                self._asteroids.remove(a)
                self._bullets.remove(b)
                

    def mediums(self,a,b):
        """
        Creates 3 medium asteroids with resultant collision vectors and
        appends them to the asteroid list.

        Sets collided attribute to False after collision
        """
        medium1 = Asteroid(MEDIUM_RADIUS*self._result1.x+a.x,MEDIUM_RADIUS*self._result1.y+a.y,\
        MEDIUM_RADIUS*2,MEDIUM_RADIUS*2,MEDIUM_IMAGE,MEDIUM_ASTEROID,MEDIUM_SPEED*self._result1)
        medium2 = Asteroid(MEDIUM_RADIUS*self._result2.x+a.x,MEDIUM_RADIUS*self._result2.y+a.y,\
        MEDIUM_RADIUS*2,MEDIUM_RADIUS*2,MEDIUM_IMAGE,MEDIUM_ASTEROID,MEDIUM_SPEED*self._result2)
        medium3 = Asteroid(MEDIUM_RADIUS*self._result3.x+a.x,MEDIUM_RADIUS*self._result3.y+a.y,\
        MEDIUM_RADIUS*2,MEDIUM_RADIUS*2,MEDIUM_IMAGE,MEDIUM_ASTEROID,MEDIUM_SPEED*self._result3)
        self._asteroids.append(medium1)
        self._asteroids.append(medium2)
        self._asteroids.append(medium3)
        self._collided = False
    
    def smalls(self,a,b):
        """
        Creates 3 small asteroids with resultant collision vectors and
        appends them to the asteroid list

        Sets collided attribute to False after collision.
        """
        small1 = Asteroid(SMALL_RADIUS*self._result1.x+a.x,SMALL_RADIUS*self._result1.y+a.y,\
        SMALL_RADIUS*2,SMALL_RADIUS*2,SMALL_IMAGE,SMALL_ASTEROID,SMALL_SPEED*self._result1)
        small2 = Asteroid(SMALL_RADIUS*self._result2.x+a.x,SMALL_RADIUS*self._result2.y+a.y,\
        SMALL_RADIUS*2,SMALL_RADIUS*2,SMALL_IMAGE,SMALL_ASTEROID,SMALL_SPEED*self._result2)
        small3 = Asteroid(SMALL_RADIUS*self._result3.x+a.x,SMALL_RADIUS*self._result3.y+a.y,\
        SMALL_RADIUS*2,SMALL_RADIUS*2,SMALL_IMAGE,SMALL_ASTEROID,SMALL_SPEED*self._result3)
        self._asteroids.append(small1)
        self._asteroids.append(small2)
        self._asteroids.append(small3)
        self._collided = False
    
    
    # RESET METHOD FOR CREATING A NEW LIFE
    def newship(self):
        """
        Called after one life is loss.

        This method creates a new ship object to continue playing the game until all lives are lost.

        Calls a helper method to prevent collision when the ship is touching an asteroid
        upon creation.
        """
        if self._lives != 0:
            self._ship = Ship(self._data['ship']['position'][0], self._data['ship']['position'][1],\
            2*SHIP_RADIUS, 2*SHIP_RADIUS, self._data['ship']['angle'], SHIP_IMAGE)
            self.respawn()
    
    def respawn(self):
        """
        This method loops over the list of asteroids and determines if there is a collision between the
        ship and an asteroid.

        A collision is detected if the distance between the center
        of two objects is less than the sum of the radii of the two circles,
        and it deletes those asteroids from the asteroid list. 
        """
        for a in self._asteroids:
            if self._ship != None:
                distance = math.sqrt((self._ship.x-a.x)**2+(self._ship.y-a.y)**2)
                if distance < SHIP_RADIUS + (a.width/2)+10:
                    self._asteroids.remove(a)
